const nav = [
    {
        linkText: 'Home',
        linkURL: '/'
    },

    {
        linkText: 'Home',
        linkURL: '/discover.html'
    },

    {
        linkText: 'Home',
        linkURL: '/locations.html'
    },

    {
        linkText: 'Home',
        linkURL: '/about.html'
    },

    {
        linkText: 'Home',
        linkURL: '/support.html'
    }
]

export default nav