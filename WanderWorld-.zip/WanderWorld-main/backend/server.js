/*const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const dbPath = path.resolve(__dirname, 'wanderworld.db');
const db = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    console.error('DB open error:', err.message);
  } else {
    console.log('Connected to DB');
    db.serialize(() => {
      db.run(`CREATE TABLE IF NOT EXISTS locations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        city TEXT
        -- add other columns as needed
      )`, (err) => {
        if (err) console.error('Create table error:', err.message);
        else console.log('Locations table ready');
      });
    });
  }
});*/
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const dbPath = path.resolve(__dirname, 'wanderworld.db');
const db = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    console.error('DB open error:', err.message);
  } else {
    console.log('Connected to DB');
    db.serialize(() => {
      db.run(`CREATE TABLE IF NOT EXISTS locations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        city TEXT
        -- add other columns as needed
      )`, (err) => {
        if (err) console.error('Create table error:', err.message);
        else console.log('Locations table ready');
      });
      // Add this new table for trip confirmation details
      db.run(`CREATE TABLE IF NOT EXISTS trip_confirmations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        trip_id INTEGER,
        confirmation_date TEXT,
        status TEXT, -- e.g., 'confirmed', 'pending', 'cancelled'
        booking_reference TEXT,
        total_price REAL,
        currency TEXT,
        -- Add any other relevant fields for trip confirmation
        FOREIGN KEY (user_id) REFERENCES users(id), -- Assuming a 'users' table exists
        FOREIGN KEY (trip_id) REFERENCES trips(id)   -- Assuming a 'trips' table exists
      )`, (err) => {
        if (err) console.error('Create trip_confirmations table error:', err.message);
        else console.log('Trip Confirmations table ready');
      });
    });
  }
});


// Define the function first
function insertTripConfirmation(confirmationData, callback) {
  const { user_id, trip_id, confirmation_date, status, booking_reference, total_price, currency } = confirmationData;
  db.run(`INSERT INTO trip_confirmations (user_id, trip_id, confirmation_date, status, booking_reference, total_price, currency) VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [user_id, trip_id, confirmation_date, status, booking_reference, total_price, currency],
    function(err) {
      if (callback) {
        callback(err, { id: this.lastID });
      }
    }
  );
}
// Then call the function
insertTripConfirmation({
  user_id: 1,
  trip_id: 101,
  confirmation_date: new Date().toISOString(),
  status: 'confirmed',
  booking_reference: 'WW123456',
  total_price: 1250.75,
  currency: 'USD'
}, (err, result) => {
  if (err) console.error('Error inserting confirmation:', err.message);
  else console.log('Trip confirmation inserted:', result);
});